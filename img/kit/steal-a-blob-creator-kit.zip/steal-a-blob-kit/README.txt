STEAL A BLOB - CREATOR KIT

Free to use in your videos, thumbnails and channel art about Steal a Blob.
Please don't sell it or use it for anything that isn't about the game.

Play: https://www.roblox.com/games/121538201522746/Steal-a-Blob
Creator program + apply: https://stealablob.com/creators.html
Discord: https://discord.gg/stealablob

Your creator code (after you're accepted): viewers type it in the game's CODES window and get 10 gems + a free Golden Egg. One creator code per Roblox account.
Your tracking link: https://stealablob.com/?ref=yt-yourname (tt- for TikTok, ig- for Instagram): it only counts how many players your videos bring.

Heads-up: Currently open to players 16+.

COLOURS
  Night         #1D0D3D   background
  Jelly purple  #3A1A73   panels
  Ink           #1C1030   outlines + text shadow
  Gold          #FFD23C   titles, money
  Cash green    #6EF08A   income
  Play green    #36D35A   buttons
  Sky blue      #59B8FF   links, info
  Pink          #FF5F9E   NEW tags

FONTS (free, Google Fonts): Luckiest Guy (titles), Fredoka One (the game's buttons)
